import cv2
import numpy as np


def get_lane_lines(img, lines):
    """将多条碎线段拟合成左右两条长直线"""
    left_lines = []
    right_lines = []

    if lines is None:
        return None

    for line in lines:
        x1, y1, x2, y2 = line[0]
        if x1 == x2: continue
        slope = (y2 - y1) / (x2 - x1)
        # 过滤斜率：左车道线斜率为负，右车道线为正（图像坐标系y轴向下）
        # 同时排除横向干扰（减速线）
        if -2.0 < slope < -0.5:
            left_lines.append([x1, y1, x2, y2])
        elif 0.5 < slope < 2.0:
            right_lines.append([x1, y1, x2, y2])

    def make_coordinates(points, image_shape):
        if not points: return None
        # 将所有点合并进行线性拟合
        points = np.array(points).reshape(-1, 2)
        [vx, vy, x, y] = cv2.fitLine(points, cv2.DIST_L2, 0, 0.01, 0.01)
        slope = vy / vx
        intercept = y - slope * x
        # 设定延伸的上下边界
        y1 = image_shape[0]  # 底部
        y2 = int(y1 * 0.6)  # 延伸到视野中部
        x1 = int((y1 - intercept) / slope)
        x2 = int((y2 - intercept) / slope)
        return [[x1, y1, x2, y2]]

    left_lane = make_coordinates(left_lines, img.shape)
    right_lane = make_coordinates(right_lines, img.shape)

    return [l for l in [left_lane, right_lane] if l is not None]


def process_image(image_path):
    # 1. 读取
    img = cv2.imread(image_path)
    if img is None: return

    # 2. 颜色过滤（HLS空间提取白色/黄色，过滤影子）
    hls = cv2.cvtColor(img, cv2.COLOR_BGR2HLS)
    white_mask = cv2.inRange(hls, np.array([0, 190, 0]), np.array([180, 255, 255]))

    # 3. 边缘检测
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5, 5), 0)
    canny = cv2.Canny(blur, 50, 150)
    refined_edges = cv2.bitwise_and(canny, white_mask)  # 只保留白色区域的边缘

    # 4. ROI 遮罩
    mask = np.zeros_like(refined_edges)
    h, w = refined_edges.shape
    polygon = np.array([[(0, h), (w, h), (w // 2, h // 2 + 50)]], np.int32)
    cv2.fillPoly(mask, polygon, 255)
    roi_edges = cv2.bitwise_and(refined_edges, mask)

    # 5. 霍夫变换（参数调整：maxLineGap调大以连接断线）
    lines = cv2.HoughLinesP(roi_edges, 1, np.pi / 180, 30, minLineLength=20, maxLineGap=200)

    # 6. 拟合与延伸（解决“线太短”的问题）
    lane_lines = get_lane_lines(img, lines)

    # 7. 绘制
    line_img = np.zeros_like(img)
    if lane_lines:
        for line in lane_lines:
            x1, y1, x2, y2 = line[0]
            cv2.line(line_img, (x1, y1), (x2, y2), (0, 255, 0), 12)  # 绿色粗线

    # 8. 叠加并只输出结果图
    result = cv2.addWeighted(img, 0.8, line_img, 1.0, 0)

    # 创建一个可以手动调整大小的窗口
    cv2.namedWindow("Lane Detection Result", cv2.WINDOW_NORMAL)

    cv2.imshow("Lane Detection Result", result)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


process_image('exp2.jpg')