from ultralytics import YOLO
import cv2

# 1. 加载预训练模型 (yolov8n 兼顾速度与精度)
model = YOLO('yolov8n.pt')

# 2. 执行检测
results = model.predict(source='exp4.jpg', save=True, conf=0.5)

# 3. 解析结果
for result in results:
    boxes = result.boxes  # 获取边界框坐标
    for box in boxes:
        # 过滤出类别为 'bicycle' 的目标 (COCO class 1)
        if int(box.cls) == 1:
            print(f"检测到共享单车，位置坐标: {box.xyxy}")