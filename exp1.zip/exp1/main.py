import numpy as np
import matplotlib.pyplot as plt
from PIL import Image


# 1. 加载并预处理图像
def load_image(path):
    img = Image.open(path).convert('RGB')
    return np.array(img)


# 2. 手动实现二维卷积 (用于滤波)
def manual_convolve(image, kernel):
    # 如果是彩色图像，转为灰度处理滤波
    if len(image.shape) == 3:
        image = 0.299 * image[:, :, 0] + 0.587 * image[:, :, 1] + 0.114 * image[:, :, 2]

    img_h, img_w = image.shape
    kh, kw = kernel.shape
    # 填充图像边缘 (Padding)
    pad_h, pad_w = kh // 2, kw // 2
    padded_img = np.pad(image, ((pad_h, pad_h), (pad_w, pad_w)), mode='edge')

    output = np.zeros_like(image)
    for i in range(img_h):
        for j in range(img_w):
            # 提取感兴趣区域 (ROI) 并进行元素乘法求和
            region = padded_img[i:i + kh, j:j + kw]
            output[i, j] = np.sum(region * kernel)
    return output


# 3. 颜色直方图计算
def manual_histogram(image):
    hist = np.zeros((3, 256))  # R, G, B 三通道
    for c in range(3):
        channel = image[:, :, c].flatten()
        for pixel in channel:
            hist[c, int(pixel)] += 1
    return hist


# 4. 纹理特征提取 (基于灰度共生矩阵 GLCM 的能量和对比度)
def extract_texture(image):
    # 转为灰度并压缩灰度级到 0-15 (减小计算量)
    gray = (0.299 * image[:, :, 0] + 0.587 * image[:, :, 1] + 0.114 * image[:, :, 2]).astype(np.uint8)
    gray = gray // 16

    glcm = np.zeros((16, 16))
    h, w = gray.shape
    # 计算水平方向 (0度) 的共生矩阵
    for i in range(h):
        for j in range(w - 1):
            row, col = gray[i, j], gray[i, j + 1]
            glcm[row, col] += 1

    glcm /= glcm.sum()  # 归一化

    # 提取特征：能量 (ASM) 和 对比度 (Contrast)
    energy = np.sum(glcm ** 2)
    contrast = 0
    for i in range(16):
        for j in range(16):
            contrast += glcm[i, j] * (i - j) ** 2

    return {"energy": energy, "contrast": contrast, "glcm_raw": glcm}


# --- 执行任务 ---

img = load_image("exp1.jpg")

# A. Sobel 算子滤波
sobel_x = np.array([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]])
sobel_y = np.array([[-1, -2, -1], [0, 0, 0], [1, 2, 1]])
grad_x = manual_convolve(img, sobel_x)
grad_y = manual_convolve(img, sobel_y)
sobel_out = np.sqrt(grad_x ** 2 + grad_y ** 2)

# B. 给定卷积核滤波 (用户提供的图片内容)
custom_kernel = np.array([
    [1, 0, -1],
    [2, 0, -2],
    [1, 0, -1]
])
custom_out = manual_convolve(img, custom_kernel)

# C. 颜色直方图
color_hist = manual_histogram(img)

# D. 纹理特征并保存
texture_features = extract_texture(img)
np.save('texture_features.npy', texture_features)

# --- 可视化 ---
plt.figure(figsize=(15, 10))
plt.subplot(231), plt.imshow(img), plt.title('Original')
plt.subplot(232), plt.imshow(sobel_out, cmap='gray'), plt.title('Sobel Filter')
plt.subplot(233), plt.imshow(np.abs(custom_out), cmap='gray'), plt.title('Custom Kernel Filter')
plt.subplot(212)
colors = ('r', 'g', 'b')
for i, col in enumerate(colors):
    plt.plot(color_hist[i], color=col, label=f'{col.upper()} channel')
plt.title('Color Histogram'), plt.legend()
plt.show()