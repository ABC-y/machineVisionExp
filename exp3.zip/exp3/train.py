# train.py
import torch
import torch.nn as nn
import torch.optim as optim
import torchvision
import torchvision.transforms as transforms
from torch.optim.lr_scheduler import StepLR  # 引入学习率调度器
from model import DigitNet

# 配置超参数
BATCH_SIZE = 128  # 增大 Batch size 可以让训练更稳定
EPOCHS = 20  # 增加训练轮数，配合学习率调度器
LEARNING_RATE = 0.001
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def train_process():
    print(f"正在启动训练，使用设备: {DEVICE}")

    # 1. 数据预处理 + 更激进的数据增强
    transform = transforms.Compose([
        # 针对 PIL 图片的操作放在前面
        transforms.RandomRotation(degrees=(-20, 20)),
        transforms.RandomAffine(degrees=0, translate=(0.15, 0.15), scale=(0.8, 1.2), shear=(-10, 10, -10, 10)),
        transforms.RandomPerspective(distortion_scale=0.2, p=0.5),

        # 关键：先转成 Tensor
        transforms.ToTensor(),

        # 针对 Tensor 的操作放在后面
        transforms.Normalize((0.1307,), (0.3081,)),
        # RandomErasing 必须在 ToTensor 之后
        transforms.RandomErasing(p=0.2, scale=(0.02, 0.1), ratio=(0.3, 3.3), value=0),
    ])

    # 加载 MNIST 数据集
    train_set = torchvision.datasets.MNIST(root='./data', train=True, download=True, transform=transform)
    train_loader = torch.utils.data.DataLoader(train_set, batch_size=BATCH_SIZE, shuffle=True)

    # 2. 初始化模型、损失函数和优化器
    model = DigitNet().to(DEVICE)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)

    # 3. 学习率调度器：每隔 5 轮学习率乘以 0.1
    scheduler = StepLR(optimizer, step_size=5, gamma=0.1)

    # 4. 训练循环
    best_acc = 0.0
    for epoch in range(EPOCHS):
        model.train()
        running_loss = 0.0
        correct = 0
        total = 0

        for i, (inputs, labels) in enumerate(train_loader):
            inputs, labels = inputs.to(DEVICE), labels.to(DEVICE)

            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            running_loss += loss.item()
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

        # 更新学习率
        scheduler.step()

        epoch_loss = running_loss / len(train_loader)
        epoch_acc = 100 * correct / total

        print(
            f'Epoch [{epoch + 1}/{EPOCHS}] | Loss: {epoch_loss:.4f} | Accuracy: {epoch_acc:.2f}% | LR: {scheduler.get_last_lr()[0]:.6f}')

        # 保存表现最好的模型
        if epoch_acc > best_acc:
            best_acc = epoch_acc
            torch.save(model.state_dict(), 'yyl_mnist_model.pth')
            print(f'  >> 保存当前最佳模型，准确率: {best_acc:.2f}%')

        if best_acc >= 99.8 and epoch > 10:  # 在高准确率下，且训练一定轮数后可以提前停止
            print("达到极高准确率，提前停止训练。")
            break

    print('-----------------------------------------')
    print(f'模型训练完成！最高准确率: {best_acc:.2f}%')
    print('最佳模型权重已保存为: yyl_mnist_model.pth')


if __name__ == '__main__':
    train_process()