# predict.py
import torch
import cv2
import numpy as np
import torchvision.transforms as transforms
import os
from model import DigitNet  # 导入模型结构
from train import train_process  # 导入训练流程（以防没有模型时自动训练）

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def predict_my_id(image_path, model):
    img = cv2.imread(image_path)
    if img is None:
        print("错误：找不到图片")
        return
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # 二值化 (注意：根据背景颜色可能需要去掉 INV)
    _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    digit_rects = []
    for cnt in contours:
        x, y, w, h = cv2.boundingRect(cnt)
        if h > 15:  # 稍微过滤噪点
            digit_rects.append((x, y, w, h))
    digit_rects.sort(key=lambda x: x[0])  # 从左到右排序

    result_string = ""
    model.eval()

    with torch.no_grad():
        for rect in digit_rects:
            x, y, w, h = rect
            # 增加padding，避免数字贴边
            pad = 10
            roi = thresh[max(0, y - pad):min(thresh.shape[0], y + h + pad),
                  max(0, x - pad):min(thresh.shape[1], x + w + pad)]

            # 调整为 28x28
            roi = cv2.resize(roi, (28, 28), interpolation=cv2.INTER_AREA)
            roi_tensor = transforms.ToTensor()(roi)
            roi_tensor = transforms.Normalize((0.1307,), (0.3081,))(roi_tensor)
            roi_tensor = roi_tensor.unsqueeze(0).to(DEVICE)

            output = model(roi_tensor)
            prediction = torch.argmax(output, dim=1).item()
            result_string += str(prediction)

            # 画图展示
            cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)
            cv2.putText(img, str(prediction), (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 0, 255), 2)

        # 1. 创建一个可以在鼠标拖动下改变大小的窗口
        window_name = "Recognition Result"
        cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)

        # 2. (可选) 设置一个默认的初始大小，比如 800x600，避免一开始太巨大
        cv2.resizeWindow(window_name, 800, 600)

        # 3. 显示图片
        cv2.imshow(window_name, img)

        # ----------------- 修改结束 -----------------

        print(f"识别结果: {result_string} (按任意键关闭窗口)")
        cv2.waitKey(0)
        cv2.destroyAllWindows()

        return result_string


if __name__ == '__main__':
    # 1. 加载或训练模型
    model = DigitNet().to(DEVICE)
    if os.path.exists('yyl_mnist_model.pth'):
        print("加载已有模型...")
        model.load_state_dict(torch.load('yyl_mnist_model.pth', map_location=DEVICE))
    else:
        print("未找到模型，开始训练...")
        train_process()  # 调用 train.py 中的函数
        model.load_state_dict(torch.load('yyl_mnist_model.pth', map_location=DEVICE))

    # 2. 预测
    image_path = 'ID.JPG'

    if os.path.exists(image_path):
        print(f"识别结果: {predict_my_id(image_path, model)}")
    else:
        print(f"请准备一张名为 {image_path} 的图片。")