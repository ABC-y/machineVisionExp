# model.py
import torch
import torch.nn as nn
import torch.nn.functional as F # 引入 F 以使用 ReLU 等函数式操作

class DigitNet(nn.Module):
    def __init__(self):
        super(DigitNet, self).__init__()
        # 增加卷积层深度
        self.conv1 = nn.Conv2d(1, 32, kernel_size=3, padding=1) # 28x28 -> 14x14
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, padding=1) # 14x14 -> 7x7
        self.conv3 = nn.Conv2d(64, 128, kernel_size=3, padding=1) # 7x7 -> 4x4 （不池化）

        # 调整全连接层输入维度，并增加一个全连接层
        # conv3输出是128个特征图，尺寸为7x7 (因为conv3后没有池化，且conv2后是7x7)
        # 实际上，如果conv3后没有pool，且conv2后是7x7，那conv3后仍是7x7
        # 让我们确保一下计算。
        # 28x28 (input)
        # conv1(kernel=3,pad=1) -> 28x28
        # MaxPool(2,2) -> 14x14
        # conv2(kernel=3,pad=1) -> 14x14
        # MaxPool(2,2) -> 7x7
        # conv3(kernel=3,pad=1) -> 7x7 (没有池化)
        self.fc1 = nn.Linear(128 * 7 * 7, 256) # 增加了神经元数量
        self.fc2 = nn.Linear(256, 128)
        self.fc3 = nn.Linear(128, 10) # 最终输出10个类别

        self.dropout = nn.Dropout(0.5) # 增加 Dropout 防止过拟合

    def forward(self, x):
        # 使用 F.relu 替换 nn.ReLU() 实例，更简洁
        x = F.relu(self.conv1(x))
        x = F.max_pool2d(x, 2, 2) # 池化
        x = F.relu(self.conv2(x))
        x = F.max_pool2d(x, 2, 2) # 池化
        x = F.relu(self.conv3(x)) # 第三层卷积后不立即池化

        x = x.view(-1, 128 * 7 * 7) # 展平
        x = F.relu(self.fc1(x))
        x = self.dropout(x) # 应用 Dropout
        x = F.relu(self.fc2(x))
        x = self.dropout(x) # 应用 Dropout
        x = self.fc3(x)
        return x